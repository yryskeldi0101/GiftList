export const cardData = [{}]
