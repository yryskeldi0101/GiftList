import React from 'react'
import LayoutPage from '../LayoutPage'

const AdminLayout = () => {
   return (
      <div>
         <LayoutPage />
      </div>
   )
}

export default AdminLayout
