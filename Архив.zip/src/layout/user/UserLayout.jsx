import React from 'react'
import LayoutPage from '../LayoutPage'

const UserLayout = () => {
   return (
      <div>
         <LayoutPage />
      </div>
   )
}

export default UserLayout
