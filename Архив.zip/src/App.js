import React, { useState } from 'react'
import { LandingPage } from './containers/LandingPage'
import ForgotPassword from './components/form/ForgotPassword'
import SingIn from './components/form/SingIn'
import SingUp from './components/form/SingUp'
import ResetPassword from './components/form/ResetPassword'

function App() {
   const [openModal, setOpenModal] = useState(false)
   const openHandler = () => {
      setOpenModal(true)
   }
   return (
      <div>
         <LandingPage openModalHandler={openHandler} />
         <ForgotPassword />
         <ResetPassword />
         <SingIn />
         <SingUp openModal={openModal} />
      </div>
   )
}

export default App
