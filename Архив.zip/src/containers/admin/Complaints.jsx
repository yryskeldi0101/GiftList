import React from 'react'

const Complaints = () => {
   return (
      <div>
         <h1>Complaints</h1>
      </div>
   )
}

export default Complaints
