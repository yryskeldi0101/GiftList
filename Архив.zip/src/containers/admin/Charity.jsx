import React from 'react'

const AdminCharity = () => {
   return (
      <div>
         <h1>AdminCharity</h1>
      </div>
   )
}

export default AdminCharity
