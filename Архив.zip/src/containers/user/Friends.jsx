import React from 'react'

const Friends = () => {
   return (
      <div>
         <h1>Friends</h1>
      </div>
   )
}

export default Friends
