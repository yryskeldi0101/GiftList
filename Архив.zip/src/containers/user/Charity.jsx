import React from 'react'

const UserCharity = () => {
   return (
      <div>
         <h1>UserCharity</h1>
      </div>
   )
}

export default UserCharity
