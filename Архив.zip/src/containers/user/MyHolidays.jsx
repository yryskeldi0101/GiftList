import React from 'react'

const MyHolidays = () => {
   return (
      <div>
         <h1>MyHolidays</h1>
      </div>
   )
}

export default MyHolidays
