import React from 'react'

const Lenta = () => {
   return (
      <div>
         <h1>Lenta</h1>
      </div>
   )
}

export default Lenta
