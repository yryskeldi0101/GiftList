import React from 'react'

const Booked = () => {
   return (
      <div>
         <h1>Booked</h1>
      </div>
   )
}

export default Booked
