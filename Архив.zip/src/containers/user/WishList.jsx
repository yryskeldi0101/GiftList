import React from 'react'

const WishList = () => {
   return (
      <div>
         <h1>WishList</h1>
      </div>
   )
}

export default WishList
